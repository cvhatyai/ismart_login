#import <Flutter/Flutter.h>

@interface AppSettingsPlugin : NSObject<FlutterPlugin>
@end
