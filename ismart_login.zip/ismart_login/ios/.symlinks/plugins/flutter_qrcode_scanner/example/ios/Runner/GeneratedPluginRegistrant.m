//
//  Generated file. Do not edit.
//

#import "GeneratedPluginRegistrant.h"

#if __has_include(<flutter_qrcode_scanner/FlutterQrcodeScannerPlugin.h>)
#import <flutter_qrcode_scanner/FlutterQrcodeScannerPlugin.h>
#else
@import flutter_qrcode_scanner;
#endif

@implementation GeneratedPluginRegistrant

+ (void)registerWithRegistry:(NSObject<FlutterPluginRegistry>*)registry {
  [FlutterQrcodeScannerPlugin registerWithRegistrar:[registry registrarForPlugin:@"FlutterQrcodeScannerPlugin"]];
}

@end
