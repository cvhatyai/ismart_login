package com.flutter.scanner.flutter_qrcode_scanner_example

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
