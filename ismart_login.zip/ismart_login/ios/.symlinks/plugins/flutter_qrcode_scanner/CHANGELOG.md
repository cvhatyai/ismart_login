## 0.0.5

* Fix permission crash
