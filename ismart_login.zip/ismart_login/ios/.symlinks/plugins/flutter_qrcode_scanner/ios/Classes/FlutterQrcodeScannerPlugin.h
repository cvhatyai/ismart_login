#import <Flutter/Flutter.h>

@interface FlutterQrcodeScannerPlugin : NSObject<FlutterPlugin>
@end
