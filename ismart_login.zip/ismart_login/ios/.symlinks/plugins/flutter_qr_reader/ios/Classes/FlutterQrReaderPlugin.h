#import <Flutter/Flutter.h>

@interface FlutterQrReaderPlugin : NSObject<FlutterPlugin>
@end
