package me.hetian.flutter_qr_reader.readerView;

public enum Orientation {
  PORTRAIT, LANDSCAPE
}
