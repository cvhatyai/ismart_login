package com.example.ismart_login

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
